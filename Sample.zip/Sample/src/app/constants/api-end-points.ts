import { environment } from 'src/environments/environment';

export const APIENDPOINTConstants = {
  GETAPICALL: `${environment.webAPIURL}api/Login/Get?`,
  POSTAPICALL: `${environment.webAPIURL}api/Login/POST?`,
};
